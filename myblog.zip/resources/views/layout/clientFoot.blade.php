<style type="text/css">
    #foot{
        height: 100px;
        background-color: #363636;
        width: 100%;
        position: relative;
        clear: both;
        float: none;
        margin-top: 100px;
    }
</style>

<div id="foot">


</div>