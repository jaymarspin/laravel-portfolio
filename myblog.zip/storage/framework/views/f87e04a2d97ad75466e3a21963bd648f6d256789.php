<?php $__env->startSection("content"); ?>
<?php echo $__env->make("admin.admin-nav", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin/works.css')); ?>">
<div class="row mycontainer time">
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.admin-head", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>