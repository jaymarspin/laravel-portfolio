<?php $__env->startSection("content"); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/client/main.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin/admin.css')); ?>">

    <?php echo $__env->make("admin.admin-nav", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make("pages.main", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make("layout.clientFoot", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>