    <style>
        
    </style>
    <script type="text/javascript">
        $(function(){
            $(".col-md-12").mouseover(function(){
                $(this).find(".hover").animate({
                    "height": "100%"
                },400,function(){
                    $(this).find("span").css({"display": "block"})
                })
            })
            $(".hover").mouseout(function(){
                $(".hover").animate({
                    "height": "0px"
                },200,function(){
                    $(this).find("span").css({"display": "none"})
                })
            })
            
        })
    </script>

<?php $datetimeFormat = 'Y-m-d H:i:s'; 

            $date = new DateTime();
            ?>
            <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php 
                    $technologies = explode(",",$rows->id);
                ?>
            <?php $__currentLoopData = $id_col; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <?php $__currentLoopData = $technologies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <?php if($item == $item2): ?>
                   <a class="col-xl-3 col-sm-12 col-md-6 col-xs-12 " href="work?work=<?php echo e($rows->id); ?>">
                    
             
                    <div class="col-md-12 col">
                            
                            <img src="<?php echo e(asset('works_images/'.$rows->images[0]->imgname.'')); ?>" />
                            <div class="article-design">


                                <i class="fa fa-eye fa-3x"></i>
                            </div>
                        <h2><?php echo e($rows->title); ?></h2>
                          
                                <div class="dater">

                                <span><?php echo e(\Carbon\Carbon::parse($rows->created_at)->format('d M')); ?> of <?php echo e(\Carbon\Carbon::parse($rows->created_at)->format('Y')); ?></span>
                              
                                </div>
                                
                                <div class="hover">
                                        <span>Click for full information</span>
                                    <div class="trans-hover">
                                    </div>
                                    
                                        
                                    </div>
                    </div>
                        
                
                </a>
                   <?php else: ?>
                       
                   <?php endif; ?>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                

 <script type="text/javascript">
    $(function(){
      
        var l = <?php echo e(sizeOf($works)); ?>;
        <?php
            $i = sizeOf($works);
            $t = $i / 10;
            $tmp = $i % 10;
           
            
            if($page[0] == null){
                if(($i / 10) < 1){
                    echo "$('.showmore').fadeOut(0)";
                }
                
            }else{ 
                if($tmp != 0){
                    $t += 1;
                }
                if($page[0] >= $t){
                    echo "$('.showmore').fadeOut(0)";
                }
            }
        
        ?>
        
        
    })

 </script>           
            

     
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          