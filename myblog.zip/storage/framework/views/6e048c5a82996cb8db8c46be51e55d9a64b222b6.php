

<?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
            <?php echo e($error); ?> <br />

        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>
<?php if(session('errorlog')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('errorlog')); ?>

        </div>
<?php endif; ?>
<?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
<?php endif; ?>